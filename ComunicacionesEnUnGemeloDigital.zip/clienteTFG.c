#include <unistd.h> 
#include <string.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <netinet/in.h> 
#include <arpa/inet.h> 
#include <netdb.h> 
#include <stdint.h>
#include <sys/select.h>
#include <errno.h>
#include <sys/stat.h>
#include <signal.h>

#define PUERTO 5000			//DEFINO PUERTO AL QUE CONECTAR
#define TAM_BUFFER 1024		//TAMAÑO BUFFER PARA INTERCAMBIAR DATOS

const char IP_SERVIDOR[]="192.168.1.1"; //IP DE PRUEBA sino se introduce una por teclado
//funcion para escritura segura
ssize_t writen(int fd, char *mensaje,size_t longitud)
{
	ssize_t a_escribir=longitud;
	ssize_t total_escrito=0;
	ssize_t escrito;
	do
	{
		errno=0;
		escrito=write(fd,mensaje+total_escrito,a_escribir);
		if(escrito>=0)
		{
			total_escrito+=escrito;
			a_escribir-=escrito;
		}
	}while(((escrito>0)&&(total_escrito<longitud))||(errno==EINTR));
	if(total_escrito>0)
	{
		return total_escrito;
	}
	else
	{
		return escrito;
	}
}
//main lo he compilado con gcc -o nombre nombre.c -std=c99
//puedo introducir la ip a conectar en ./nombre ip
int main(int argc, char *argv[])
{
	int sd;       		//descriptor del socket
	struct sockaddr_in serv_dir;		//estructura del servidor
	uint32_t direccion_IP;		//direcicon ip
	fd_set cjto_descriptores,cjto_modificado;	//conjunto descriptores
	char buffer[TAM_BUFFER];
	//sino se introduce una ip se pone la de por defecto
	if(argc<2)
	{
		printf("se usa la ip por defecto");
		direccion_IP=inet_addr(IP_SERVIDOR);
	}
	else
	{
		direccion_IP=inet_addr(argv[1]);
	}
	if(direccion_IP<0)
	{
		printf("error en inet\n");
		exit(1);
	}
	
	//1º creamos el socket
	sd=socket(AF_INET,SOCK_STREAM,0);
	if(sd<0)
	{
		perror("socket");
		exit(1);
	}
	
	//rellenamos la estructura con el servidor para darle al conect
		//primero ponemos todo a 0
	memset(&serv_dir,0,sizeof(serv_dir));
	serv_dir.sin_family=AF_INET;	//añado la familia
	serv_dir.sin_port=htons(PUERTO); //añado el puerto formato big endian
	memcpy(&serv_dir.sin_addr,&direccion_IP,4); //copio la ip 
	
	//2ºel conect 
	if(connect(sd,(struct sockaddr *)&serv_dir,sizeof(serv_dir))<0)
	{
		perror("error en connect");
		exit(1);
	}
	
	//inicializo el fd_Set A 0
	FD_ZERO(&cjto_descriptores);
	//añado el socket par el select y el descriptor de teclado
	FD_SET(sd,&cjto_descriptores);
	FD_SET(0,&cjto_descriptores);
	
	//3 bucle con select
	//mensaje para pantalla
	write(1,"introduzca mensaje:",19);
	while(1)
	{	
		
		//hacemos copia de los descriptores
		memcpy(&cjto_modificado,&cjto_descriptores,sizeof(fd_set));
		//ahora puedo llamar a select ya que este modifica los descriptores
		int res=select(sd+1,&cjto_modificado,NULL,NULL,NULL); //habria que ver el maximo descriptor en este caso como solo esta socket y 0, el mayor es socket
		if(res<0)
		{
				perror("error en select");
				close(sd);
				exit(1);
		}
		//Compruebo si el socket esta listo paara leer
		if(FD_ISSET(sd,&cjto_modificado))
		{
			//4 ahora hacemos el read y el write
			int leido=read(sd,buffer,TAM_BUFFER);
			if(leido<0)
			{
				perror("error al leer");
				close(sd);
				exit(1);
			}
			else if(leido==0)//se ha cerrado la conexion en el otro extremo
			{
				FD_CLR(sd,&cjto_modificado);
				close(sd);
				printf("se ha cerrado la conexion");
				return 0;
			}
			else
			{
				//muestro por pantalla lo leido
				buffer[leido]='\0';
				writen(1,buffer,leido);
			}
		}//fin del fdiset socket
		//si es el teclado
		if(FD_ISSET(0,&cjto_modificado))
		{
			//leo de teclado
			int leidoteclado=read(0,buffer,TAM_BUFFER);
			if(leidoteclado<0)
			{
				perror("fallo al leer");
				exit(1);
			}
			else
			{
				//escribo por el socket los datos
				writen(sd,buffer,leidoteclado);
			}
		}
	}//fin while
}
